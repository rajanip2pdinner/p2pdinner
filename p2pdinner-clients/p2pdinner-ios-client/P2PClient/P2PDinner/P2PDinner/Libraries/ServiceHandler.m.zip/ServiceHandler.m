//
//  P2PServiceHandler.m
//  P2PDinner
//
//  Created by sudheerkumar on 2/28/15.
//  Copyright (c) 2015 P2PDinner. All rights reserved.
//

#import "ServiceHandler.h"
#import "Utility.h"
#import "AFNetworking.h"
static ServiceHandler *_sharedInstance=nil;
@interface ServiceHandler()<NSURLConnectionDelegate>
@property(nonatomic,retain)NSMutableURLRequest *request;
@property(nonatomic,retain)NSMutableData *responseData;
@end
@implementation ServiceHandler
+(id)sharedServiceHandler
{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        _sharedInstance = [[self alloc] init];
    });
    return _sharedInstance;
}
-(void)execute:(NSString *)url requestObject:(NSString *)requestValue contentType:(NSString *)contentType requestMethodGetServiceCallBack:(ServiceResultBlock)serviceCallBackBlock{
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"JSON: %@", responseObject);
        serviceCallBackBlock(nil,responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
         serviceCallBackBlock(error,nil);
        
    }];
    
}
-(void)execute:(NSString *)url requestObject:(NSString *)requestValue contentType:(NSString *)contentType requestMethodPostServiceCallBack:(ServiceResultBlock)serviceCallBackBlock{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:url parameters:requestValue success:^(AFHTTPRequestOperation *operation, id responseObject){
        
        NSLog(@"JSON: %@", responseObject);
        serviceCallBackBlock(nil,responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        NSLog(@"Error: %@", error);
        serviceCallBackBlock(error,nil);
        
    }];
}
-(void)execute:(NSString *)url requestObject:(NSString *)requestValue contentType:(NSString *)contentType requestMethod:(NSString *)requestMethod serviceCallBack:(ServiceResultBlock)serviceCallBackBlock{
    resultBlock=serviceCallBackBlock;
    if ([requestMethod isEqualToString:@"GET"]) {
        url=[NSString stringWithFormat:@"%@?%@",url,[Utility jsonStringToURLParameter:requestValue]];
    }
    _request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60];
    
    // Specify that it will be a POST request
    _request.HTTPMethod = requestMethod;
    
    // This is how we set header fields
    [_request setValue:contentType forHTTPHeaderField:@"Content-Type"];
    if ([requestMethod isEqualToString:@"POST"]) {
    // Convert your data and set your request's HTTPBody property
    NSData *requestBodyData = [requestValue dataUsingEncoding:NSUTF8StringEncoding];
    _request.HTTPBody = requestBodyData;
    }
    
    // Create url connection and fire request
    NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:_request delegate:self];
    
    [conn start];
    
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    _responseData = [[NSMutableData alloc] init];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [_responseData appendData:data];
}

- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
    return nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    NSError *e = nil;
    resultBlock(nil,[NSJSONSerialization JSONObjectWithData:_responseData options: NSJSONReadingMutableContainers error: &e]);
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
    
    resultBlock(error,nil);
}
@end
